#include <iostream>
#include<algorithm>
#include <vector>

using namespace std;

const int dx[4] = { 1, -1, 0, 0 }; // ���������ĸ�����
const int dy[4] = { 0, 0, 1, -1 };

int N; // �����С
char grid[10005][10005]; // ����
int melt_count[10005][10005];
vector<pair<int, int>> v1;
vector<pair<int, int>> v2;
// �ж��Ƿ���������
bool is_valid(int x, int y) {
    return x >= 1 && x <= N && y >= 1 && y <= N;
}

void liquid(int x, int y)
{
    for (int i = 0; i < 4; i++) {
        int nx = x + dx[i];
        int ny = y + dy[i];
        if (grid[nx][ny] == '_')
        {
            grid[nx][ny] = 'L';
            for (int i = 0; i < 4; i++)
            {
                if (is_valid(nx + dx[i], ny + dy[i]))
                {
                    if (grid[nx + dx[i]][ny + dy[i]] == '#')
                    {
                        melt_count[nx + dx[i]][ny + dy[i]]++;
                        if (melt_count[nx + dx[i]][ny + dy[i]] >= 2&&
                            find(v2.begin(),v2.end(),pair<int,int>(nx+dx[i],ny+dy[i]))==v2.end())
                            v2.push_back({ nx + dx[i] ,ny + dy[i] });
                    }
                }
            }
            if(is_valid(nx, ny))
                liquid(nx, ny);
        }
    }
}
void bfs() {
    for (auto a : v1)
    {
        int x = a.first;
        int y = a.second;
        grid[x][y] = 'L';
        for (int i = 0; i < 4; i++) {
            if (is_valid(x + dx[i], y + dy[i]))
            {
                if (grid[x + dx[i]][y + dy[i]] == '#')
                {
                    melt_count[x + dx[i]][y + dy[i]]++;
                    if (melt_count[x + dx[i]][y + dy[i]] >= 2 && 
                        find(v2.begin(), v2.end(), pair<int, int>(x + dx[i], y + dy[i])) == v2.end())
                    {
                        v2.push_back({ x + dx[i] ,y + dy[i] });
                    }
                }
                else if (grid[x + dx[i]][y + dy[i]] == '_')
                {
                    liquid(x + dx[i], y + dy[i]);
                }
            }
            
        }
    }
    swap(v1, v2);//O(1),���Ƕ���ΪO(n)
    v2.clear();
}

int main() {
    cin >> N;

    // ��������
    for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= N; j++) {
            cin >> grid[i][j];
        }
    }

    // ���Һ���ʼ�������Ĭ��Ϊ�ӣ�1��1����ʼ������ⲿ��ͨ
    liquid(1, 1);
    swap(v1, v2);
    /*for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= N; j++) {
            cout << grid[i][j];
        }
        cout << endl;
    }
    for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= N; j++) {
            cout<<melt_count[i][j];
        }
        cout << endl;
    }
    for (auto x : v1)
    {
        cout << x.first << "," << x.second << endl;
    }*/
    int time = 0;
    while (!v1.empty()) {
        bfs();
        time++;
    }

    cout << time << endl;

    return 0;
}
