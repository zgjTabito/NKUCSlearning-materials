//#include<iostream>
//#include<vector>
//#include<algorithm>
//#include<fstream>
//#include<string>
//using namespace std;
//
//class Position {
//public:
//    int fileindex;
//    int row;
//    int column;
//    Position* next;
//    Position(int fileindex, int row, int column) {
//        this->fileindex = fileindex;
//        this->row = row;
//        this->column = column;
//        this->next = nullptr;
//    }
//};
//
//class PositionList {
//public:
//    Position* head = nullptr;
//    int count = 0;
//    void insert(Position* p) {
//        count++;
//        if (head == nullptr) {
//            head = p;
//            return;
//        }
//        Position* cur = head;
//        while (cur->next != nullptr)
//            cur = cur->next;
//        cur->next = p;
//    }
//};
//
//class Node {
//public:
//    string s;
//    int count;
//    int ASCIIindex;
//    int countindex;
//    PositionList head;
//    PositionList rear;
//    Node(string s, Position* head, Position* rear) {
//        this->s = s;
//        this->head.insert(head);
//        this->rear.insert(rear);
//        ASCIIindex = -1;
//        countindex = -1;
//        count = 1;
//    }
//};
//
//// �����Ƿ��ظ�
//int findNode(vector<Node>& wordList, string& cur) {
//    for (int i = 0; i < wordList.size(); i++) {
//        if (wordList[i].s == cur)
//            return i;
//    }
//    return -1;
//}
//
//bool comparebyASCII(const Node& node1, const Node& node2) {
//    return node1.s < node2.s;
//}
//
//// ����ASCII����
//void updateASCIIIndexes(vector<Node>::iterator start, vector<Node>& wordList) {
//    while (start != wordList.end()) {
//        start->ASCIIindex = distance(wordList.begin(), start) + 1;
//        ++start;
//    }
//}
//
//// �����������ֶ��ָ��ַ������ҳ�ÿ������[a-zA-Z]+�ĵ���
//void processLine(int fileindex, string& line, int row, vector<Node>& wordList) {
//    string cur;
//    int col = 1;  // �кŴ�1��ʼ
//    while (col <= line.length()) {
//        if (isalpha(line[col - 1])) {
//            char a = (line[col - 1] >= 'A' && line[col - 1] <= 'Z') ? (line[col - 1] - 'A' + 'a') : line[col - 1];
//            cur += a;
//        }
//        else if (!cur.empty()) {
//            Position* head = new Position(fileindex, row, col - cur.length());
//            Position* rear = new Position(fileindex, row, col - 1); // rear ��¼���ʽ���λ��
//            int temp = findNode(wordList, cur);
//            if (temp != -1) {
//                wordList[temp].head.insert(head);
//                wordList[temp].rear.insert(rear);
//                wordList[temp].count++;
//            }
//            else {
//                Node newWord(cur, head, rear);
//                auto it = lower_bound(wordList.begin(), wordList.end(), newWord, comparebyASCII);
//                wordList.insert(it, newWord);
//                it = lower_bound(wordList.begin(), wordList.end(), newWord, comparebyASCII);
//                updateASCIIIndexes(it, wordList);  
//            }
//            cur.clear();
//        }
//        col++;
//    }
//    // ������β�ĵ���
//    if (!cur.empty()) {
//        Position* head = new Position(fileindex, row, col - cur.length());
//        Position* rear = new Position(fileindex, row, col - 1); // ������β
//        int temp = findNode(wordList, cur);
//        if (temp != -1) {
//            wordList[temp].head.insert(head);
//            wordList[temp].rear.insert(rear);
//            wordList[temp].count++;
//        }
//        else {
//            Node newWord(cur, head, rear);
//            auto it = lower_bound(wordList.begin(), wordList.end(), newWord, comparebyASCII);
//            wordList.insert(it, newWord);
//            it = lower_bound(wordList.begin(), wordList.end(), newWord, comparebyASCII);
//            updateASCIIIndexes(it, wordList);
//        }
//    }
//}
//
//
//
//
//// ����ʱ�״̬���ļ�
//void outputWordList(vector<Node>& wordList, string& outFileName) {
//    ofstream outFile(outFileName);
//    for (Node& node : wordList) {
//        outFile << node.s << ";" << node.count << ";";
//        Position* p = node.head.head;
//        while (p != nullptr) {
//            outFile << "(" << p->fileindex << "," << p->row << "," << p->column << ");";
//            p = p->next;
//        }
//        outFile << endl;
//    }
//    outFile.close();
//}
//
//int main(int argc, char* argv[]) {
//    vector<Node> wordList;  // �洢���е��ʵ���Ϣ
//    // ����ÿ�������ļ�
//    for (int fileIndex = 1; fileIndex < argc; fileIndex++) {
//        ifstream file(argv[fileIndex]);
//        string line;
//        int row = 1;  // �кŴ�1��ʼ
//        while (getline(file, line)) {
//            processLine(fileIndex, line, row, wordList);  // ������ǰ��
//            row++;  // ������һ�У��к�+1
//        }
//        file.close();  // �رյ�ǰ�����ļ�
//        // ��̬��������ļ���
//        string outFileName = "out" + to_string(fileIndex) + ".txt";
//        outputWordList(wordList, outFileName);  // �����ǰ�ʱ�״̬
//    }
//    return 0;
//}