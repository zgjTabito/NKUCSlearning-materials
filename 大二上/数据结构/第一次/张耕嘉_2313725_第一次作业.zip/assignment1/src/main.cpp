#include<iostream>
#include<vector>
#include<algorithm>
#include<fstream>
#include<string>
using namespace std;

class Position {
public:
    int fileindex;
    int row;
    int column;
    Position* next;
    Position(int fileindex, int row, int column) {
        this->fileindex = fileindex;
        this->row = row;
        this->column = column;
        this->next = nullptr;
    }
};

class PositionList {
public:
    Position* head = nullptr;
    int count = 0;
    void insert(Position* p) {
        count++;
        if (head == nullptr) {
            head = p;
            return;
        }
        Position* cur = head;
        while (cur->next != nullptr)
            cur = cur->next;
        cur->next = p;
    }
};

class Node {
public:
    string s;
    int count;
    int ASCIIindex;
    int countindex;
    PositionList head;
    PositionList rear;
    Node(string s, Position* head, Position* rear) {
        this->s = s;
        this->head.insert(head);
        this->rear.insert(rear);
        ASCIIindex = -1;
        countindex = -1;
        count = 1;
    }
};

// �����Ƿ��ظ�
int findNode(vector<Node>& wordList, string& cur) {
    for (int i = 0; i < wordList.size(); i++) {
        if (wordList[i].s == cur)
            return i;
    }
    return -1;
}

// ��ASCII����
bool comparebyASCII(Node& node1, Node& node2) {
    return node1.s < node2.s;
}

// ����Ƶ����
bool comparebycount(Node& node1, Node& node2) {
    return node1.count > node2.count;
}

// ���¶�̬����
void updateIndexes(vector<Node>& wordList) {
    sort(wordList.begin(), wordList.end(), comparebycount);
    for (int i = 0; i < wordList.size(); i++) {
        wordList[i].countindex = i + 1;
    }
    sort(wordList.begin(), wordList.end(), comparebyASCII);
    for (int i = 0; i < wordList.size(); i++) {
        wordList[i].ASCIIindex = i + 1;
    }
}

// �����������ֶ��ָ��ַ������ҳ�ÿ������[a-zA-Z]+�ĵ���
void processLine(int fileindex, string& line, int row, vector<Node>& wordList) {
    string cur;
    int col = 1;  // �кŴ�1��ʼ
    while (line[col - 1] != '\0') {
        if (isalpha(line[col - 1])) {
            char a = (line[col - 1] >= 'A' && line[col - 1] <= 'Z') ? (line[col - 1] - 'A' + 'a') : line[col - 1];
            cur += a;
        }
        else if (!cur.empty()) {
            Position* head = new Position(fileindex, row, col - cur.length());
            Position* rear = new Position(fileindex, row, col);
            int temp = findNode(wordList, cur);
            if (temp != -1) {
                wordList[temp].head.insert(head);
                wordList[temp].rear.insert(rear);
                wordList[temp].count++;
            }
            else {
                Node newWord(cur, head, rear);
                wordList.push_back(newWord);
            }
            updateIndexes(wordList);  // ��������
            cur.clear();
        }
        col++;
    }
}

// ����ʱ�״̬���ļ�
void outputWordList(vector<Node>& wordList, string& outFileName) {
    ofstream outFile(outFileName);
    for (Node& node : wordList) {
        outFile << node.s << ";" << node.count << ";";
        Position* p = node.head.head;
        while (p != nullptr) {
            outFile << "(" << p->fileindex << "," << p->row << "," << p->column << ");";
            p = p->next;
        }
        outFile << endl;
    }
    outFile.close();
}

int main(int argc, char* argv[]) {
    vector<Node> wordList;  // �洢���е��ʵ���Ϣ
    // ����ÿ�������ļ�
    for (int fileIndex = 1; fileIndex < argc; fileIndex++) {
        ifstream file(argv[fileIndex]);
        if (!file.is_open()) {
            cerr << "Error: Could not open the file " << argv[fileIndex] << endl;
            return 1;
        }
        string line;
        int row = 1;  // �кŴ�1��ʼ
        while (getline(file, line)) {
            processLine(fileIndex, line, row, wordList);  // ������ǰ��
            row++;  // ������һ�У��к�+1
        }
        file.close();  // �رյ�ǰ�����ļ�
        // ��̬��������ļ���
        string outFileName = "out" + to_string(fileIndex) + ".txt";
        outputWordList(wordList, outFileName);  // �����ǰ�ʱ�״̬
    }
    return 0;
}