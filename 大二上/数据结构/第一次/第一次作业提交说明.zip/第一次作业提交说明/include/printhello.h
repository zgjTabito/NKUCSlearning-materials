// define the print-hello function head
#ifndef PRINTHELLO_H
#define PRINTHELLO_H

void print_hello();

#endif