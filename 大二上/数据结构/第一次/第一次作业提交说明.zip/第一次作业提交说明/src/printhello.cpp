// implement the function of print_hello
#include <iostream>
#include "printhello.h"

void print_hello() {
    std::cout << "Hello, World!" << std::endl;
}