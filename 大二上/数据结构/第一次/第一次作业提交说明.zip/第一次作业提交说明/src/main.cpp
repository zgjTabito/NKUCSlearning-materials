// call the print_hello function in main
#include "printhello.h"

int main() {
    print_hello();
    return 0;
}
